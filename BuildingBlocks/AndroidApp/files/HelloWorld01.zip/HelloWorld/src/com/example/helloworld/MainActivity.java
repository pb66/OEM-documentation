package com.example.helloworld;

import java.io.BufferedInputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Activity;
import android.util.Log;
import android.view.Menu;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
	    super.onCreate(savedInstanceState);
	    setContentView(R.layout.activity_main);
	
	    try {
		    String result = new HTTP().execute("http://emoncms.org/feed/value.json?apikey=7f1b46367a013db07d2d65e588d2ad93&id=43348").get();
		    Log.i("EmonLog", "Result: "+result);
	    } catch (Exception e) {
		    Log.i("EmonLog", "Error: "+e);
	    }
    }

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}

class HTTP extends AsyncTask<String, Void, String>
{
    @Override
    protected String doInBackground(String... params) {
	    String result = "";
	    try {
		    String urlstring = params[0];
		    Log.i("EmonLog", "HTTP Connecting: "+urlstring);
		    URL url = new URL(urlstring);
		    HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
		
		    try {
		        InputStream reader = new BufferedInputStream(urlConnection.getInputStream());
		        
		        String text = "";
		        int i = 0;
		        while((i=reader.read())!=-1)
		        {
		            text += (char)i;
		        }
		        Log.i("EmonLog", "HTTP Response: "+text);
		        result = text;
		        
		    } catch (Exception e) {
			    Log.i("EmonLog", "HTTP Exception: "+e);
		    }
		    finally {
			    Log.i("EmonLog", "HTTP Disconnecting");
	            urlConnection.disconnect();
		    }
		
	    } catch (Exception e) {
		    e.printStackTrace();
		    Log.i("EmonLog", "HTTP Exception: "+e);
	    }
	
	    return result;
    }
}
